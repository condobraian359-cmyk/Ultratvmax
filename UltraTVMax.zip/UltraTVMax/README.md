# Ultra TV Max

App Android (Kotlin + Jetpack Compose + Media3) para descubrir y reproducir películas, series y TV en vivo
**solo desde fuentes autorizadas**. Interfaz oscura, pensada para gama baja y Android TV.

## Módulos
- `:core:data` – modelos, red con caché de 20 MB, fuentes de catálogo, M3U, EPG, ajustes (DataStore).
- `:feature:player` – reproductor Media3/ExoPlayer (HLS/DASH, audio/subtítulos/calidad, reanudar, failover entre fuentes).
- `:app` – UI Compose: Inicio, Buscador, TV en vivo, Ajustes.

## Compilar
1. Abre la carpeta en **Android Studio** (Koala o superior, JDK 17). Sincroniza Gradle.
2. APK de prueba: `Build > Build APK(s)` o `./gradlew assembleDebug`
   → `app/build/outputs/apk/debug/app-debug.apk`
3. APK de release: configura tu propia firma y usa `./gradlew assembleRelease` (R8 y reducción de recursos activados).
   (Si falta `gradlew`, ejecuta `gradle wrapper --gradle-version 8.9` o deja que Android Studio lo genere.)

## Configurar fuentes (dentro de la app → Ajustes)
- **TMDB**: crea una cuenta gratis en themoviedb.org y pega tu API key o token. Se guarda solo en el dispositivo; nunca va en el APK.
  TMDB aporta fichas (póster, sinopsis, año, género, plataformas donde se ve). **No reproduce nada.**
- **Internet Archive (cine de dominio público)**: activo por defecto, sin clave.
- **Listas M3U**: por defecto Free-TV (canales gratuitos). Agrega otras listas que tengas derecho a usar.
- **EPG**: URL XMLTV (`.xml` o `.xml.gz`) cuyos `channel id` coincidan con el `tvg-id` de tu M3U.

## Cómo se evita mostrar contenido roto
- Cada título es `Playable` (hay enlace verificado con `LinkChecker`) o `InfoOnly` (ficha). La UI los rotula distinto.
- Los títulos de Internet Archive solo aparecen si su archivo responde.
- Los canales se verifican al abrirlos; si caen, se avisa y no se reproduce.
- En el reproductor, si una fuente falla se salta a la siguiente; si todas fallan, se informa.

## Añadir una fuente nueva
Implementa `CatalogSource` (`browse`, `search`, `resolve`) y agrégala en `AppViewModel`.
Para devolver `Playable`, entrega `Stream(url, label, audioLang, subtitles)` ya verificados.

## Pendiente / siguientes fases
- Detalle de series con temporadas/episodios (TMDB `/tv/{id}/season/{n}`) y su mapeo a fuentes que lo permitan.
- Panel de administración web (hoy: ajustes dentro de la app).
- Banner de Android TV (`android:banner`) y navegación optimizada para control remoto.
- Paginación del catálogo y filtros por país/plataforma en servidor.
