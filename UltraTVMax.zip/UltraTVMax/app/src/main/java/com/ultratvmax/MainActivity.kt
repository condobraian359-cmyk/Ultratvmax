package com.ultratvmax

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.ultratvmax.core.data.Availability
import com.ultratvmax.feature.player.PlayerScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFE50914), background = Color(0xFF0B0B0F), surface = Color(0xFF14141A),
                ),
            ) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val playback by vm.playback.collectAsStateWithLifecycle()
    val detail by vm.detail.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    LaunchedEffect(message) { message?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.message.value = null } }

    val req = playback
    if (req != null) {
        BackHandler { vm.playback.value = null }
        val start by produceState<Long?>(null, req.key) { value = if (req.live) 0L else vm.settings.progress(req.key) }
        start?.let { s ->
            PlayerScreen(req, s, onSaveProgress = { vm.saveProgress(req.key, it) }, onClose = { vm.playback.value = null })
        }
    } else {
        val nav = rememberNavController()
        val tabs = listOf(
            Triple("home", "Inicio", Icons.Default.Home),
            Triple("search", "Buscar", Icons.Default.Search),
            Triple("live", "TV en vivo", Icons.Default.Tv),
            Triple("settings", "Ajustes", Icons.Default.Settings),
        )
        val current = nav.currentBackStackEntryAsState().value?.destination?.route
        Scaffold(bottomBar = {
            NavigationBar {
                tabs.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = current == route,
                        onClick = { nav.navigate(route) { popUpTo("home"); launchSingleTop = true } },
                        icon = { Icon(icon, label) }, label = { Text(label) },
                    )
                }
            }
        }) { pad ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                composable("home") { HomeScreen(vm) }
                composable("search") { SearchScreen(vm) }
                composable("live") { LiveScreen(vm) }
                composable("settings") { SettingsScreen(vm) }
            }
        }
        detail?.let { t ->
            AlertDialog(
                onDismissRequest = { vm.detail.value = null },
                confirmButton = { TextButton(onClick = { vm.detail.value = null }) { Text("Cerrar") } },
                title = { Text("${t.name}${t.year?.let { " ($it)" } ?: ""}") },
                text = {
                    val platforms = (t.availability as? Availability.InfoOnly)?.platforms.orEmpty()
                    Text(
                        (t.overview ?: "Sin sinopsis.") + "\n\nNo hay fuente reproducible autorizada en esta app para este título." +
                            if (platforms.isNotEmpty()) "\nDisponible en: ${platforms.joinToString()}" else "",
                    )
                },
            )
        }
    }
}
