package com.ultratvmax

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.ultratvmax.core.data.Availability
import com.ultratvmax.core.data.MediaType
import com.ultratvmax.core.data.Title
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun TitleCard(t: Title, onClick: () -> Unit) {
    val playable = t.availability is Availability.Playable
    Column(Modifier.width(120.dp).clickable(onClick = onClick)) {
        Box {
            AsyncImage(
                model = t.posterUrl, contentDescription = t.name, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp)).background(Color(0xFF222230)),
            )
            Text(
                if (playable) "▶ Ver" else "Ficha", color = Color.White, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.TopStart).padding(4.dp)
                    .background(if (playable) Color(0xFF1B8F3A) else Color(0xFF555566), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 1.dp),
            )
        }
        Text(t.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun HomeScreen(vm: AppViewModel) {
    val rows by vm.homeRows.collectAsStateWithLifecycle()
    val loaded by vm.homeLoaded.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { if (rows.isEmpty()) vm.loadHome() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("Ultra TV Max", fontSize = 22.sp, color = MaterialTheme.colorScheme.primary) }
        if (!loaded) item { CircularProgressIndicator() }
        items(rows) { (title, list) ->
            Column {
                Text(title, fontSize = 16.sp, modifier = Modifier.padding(bottom = 6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.id }) { t -> TitleCard(t) { vm.open(t) } }
                }
            }
        }
        if (loaded && rows.none { it.first.contains("TMDB") }) {
            item { Text("Para ver tendencias y fichas mundiales, agrega tu clave gratuita de TMDB en Ajustes.", fontSize = 13.sp) }
        }
    }
}

@Composable
fun SearchScreen(vm: AppViewModel) {
    val results by vm.results.collectAsStateWithLifecycle()
    val searching by vm.searching.collectAsStateWithLifecycle()
    var q by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("") }
    var onlyPlayable by rememberSaveable { mutableStateOf(false) }
    var type by rememberSaveable { mutableStateOf<MediaType?>(null) }

    LaunchedEffect(q) { if (q.trim().length >= 2) { delay(500); vm.search(q.trim()) } }

    val shown = results.filter { t ->
        (!onlyPlayable || t.availability is Availability.Playable) &&
            (type == null || t.type == type) &&
            (filter.isBlank() || "${t.genres.joinToString()} ${t.year} ${t.language}".contains(filter.trim(), ignoreCase = true))
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(q, { q = it }, label = { Text("Título, actor o director") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(filter, { filter = it }, label = { Text("Filtrar: género, año, idioma (es, en, ja…)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 6.dp)) {
            item { FilterChip(onlyPlayable, { onlyPlayable = !onlyPlayable }, { Text("Solo reproducibles") }) }
            items(listOf(MediaType.MOVIE to "Películas", MediaType.SERIES to "Series", MediaType.ANIME to "Anime")) { (m, label) ->
                FilterChip(type == m, { type = if (type == m) null else m }, { Text(label) })
            }
        }
        if (searching) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyVerticalGrid(GridCells.Adaptive(110.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(shown, key = { it.id }) { t -> TitleCard(t) { vm.open(t) } }
        }
    }
}

@Composable
fun LiveScreen(vm: AppViewModel) {
    val channels by vm.channels.collectAsStateWithLifecycle()
    val loading by vm.channelsLoading.collectAsStateWithLifecycle()
    val epg by vm.epg.collectAsStateWithLifecycle()
    val favs by vm.settings.favorites.collectAsStateWithLifecycle(emptySet())
    var q by rememberSaveable { mutableStateOf("") }
    var onlyFav by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) { if (channels.isEmpty()) vm.loadChannels() }

    val now = System.currentTimeMillis()
    val shown = channels.filter { c ->
        (!onlyFav || c.id in favs) && (q.isBlank() || c.name.contains(q, true) || (c.group ?: "").contains(q, true))
    }.sortedByDescending { it.id in favs }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(q, { q = it }, label = { Text("Buscar canal o categoría") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        FilterChip(onlyFav, { onlyFav = !onlyFav }, { Text("Favoritos") }, modifier = Modifier.padding(vertical = 6.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn {
            items(shown, key = { it.url }) { c ->
                val nowPlaying = c.tvgId?.let { epg[it] }?.firstOrNull { now in it.start..it.stop }?.title
                Row(Modifier.fillMaxWidth().clickable { vm.playChannel(c) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(c.logo, c.name, Modifier.size(48.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF222230)), contentScale = ContentScale.Fit)
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(c.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(nowPlaying?.let { "Ahora: $it" } ?: (c.group ?: ""), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    val fav = c.id in favs
                    IconButton(onClick = { vm.toggleFav(c.id) }) { Icon(if (fav) Icons.Default.Star else Icons.Default.StarBorder, "Favorito") }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val scope = rememberCoroutineScope()
    val key by vm.settings.tmdbKey.collectAsStateWithLifecycle("")
    val m3u by vm.settings.m3uUrls.collectAsStateWithLifecycle(emptySet())
    val epgUrl by vm.settings.epgUrl.collectAsStateWithLifecycle("")
    var keyField by remember(key) { mutableStateOf(key) }
    var newM3u by remember { mutableStateOf("") }
    var epgField by remember(epgUrl) { mutableStateOf(epgUrl) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Fuentes", fontSize = 20.sp) }
        item {
            Text("Clave de TMDB (gratis en themoviedb.org). Se guarda solo en tu dispositivo.", fontSize = 13.sp)
            OutlinedTextField(keyField, { keyField = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text("API key o token") })
            Button(onClick = { scope.launch { vm.settings.setTmdbKey(keyField); vm.loadHome() } }) { Text("Guardar clave") }
        }
        item { Text("Listas M3U autorizadas", fontSize = 16.sp) }
        items(m3u.toList()) { u ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(u, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                TextButton(onClick = { scope.launch { vm.settings.removeM3u(u); vm.loadChannels() } }) { Text("Quitar") }
            }
        }
        item {
            OutlinedTextField(newM3u, { newM3u = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text("URL de lista M3U") })
            Button(onClick = { if (newM3u.startsWith("http")) scope.launch { vm.settings.addM3u(newM3u); newM3u = ""; vm.loadChannels() } }) { Text("Agregar lista") }
        }
        item {
            Text("Guía de programación (XMLTV .xml o .xml.gz)", fontSize = 16.sp)
            OutlinedTextField(epgField, { epgField = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text("URL de EPG") })
            Button(onClick = { scope.launch { vm.settings.setEpg(epgField); vm.loadChannels() } }) { Text("Guardar EPG") }
        }
        item { Text("Agrega solo listas y fuentes que tengas derecho a usar.", fontSize = 12.sp) }
    }
}
