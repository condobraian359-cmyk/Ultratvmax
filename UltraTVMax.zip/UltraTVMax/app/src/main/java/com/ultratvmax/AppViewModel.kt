package com.ultratvmax

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ultratvmax.core.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val settings = SettingsStore(app)
    private val archive = ArchiveSource()
    // Para añadir otra fuente autorizada: implementa CatalogSource y agrégala a esta lista.
    private val repo = CatalogRepository(listOf(TmdbSource { settings.tmdbKey.first() }, archive), archive)

    val homeRows = MutableStateFlow<List<Pair<String, List<Title>>>>(emptyList())
    val homeLoaded = MutableStateFlow(false)
    val results = MutableStateFlow<List<Title>>(emptyList())
    val searching = MutableStateFlow(false)
    val channels = MutableStateFlow<List<Channel>>(emptyList())
    val channelsLoading = MutableStateFlow(false)
    val epg = MutableStateFlow<Map<String, List<Programme>>>(emptyMap())
    val playback = MutableStateFlow<PlaybackRequest?>(null)
    val detail = MutableStateFlow<Title?>(null)
    val message = MutableStateFlow<String?>(null)

    init { Http.init(app) }

    fun loadHome() = viewModelScope.launch {
        homeLoaded.value = false
        homeRows.value = repo.home()
        homeLoaded.value = true
    }

    fun search(q: String) = viewModelScope.launch {
        searching.value = true
        results.value = runCatching { repo.search(q) }.getOrDefault(emptyList())
        searching.value = false
    }

    fun open(t: Title) = viewModelScope.launch {
        val r = repo.resolve(t)
        when (val a = r.availability) {
            is Availability.Playable -> playback.value = PlaybackRequest("vod:${r.id}", r.name, a.streams, live = false)
            is Availability.InfoOnly -> detail.value = r
        }
    }

    fun loadChannels() = viewModelScope.launch {
        channelsLoading.value = true
        val list = settings.m3uUrls.first().flatMap { runCatching { M3u.load(it) }.getOrDefault(emptyList()) }
        channels.value = list.distinctBy { it.url }
        val epgUrl = settings.epgUrl.first()
        if (epgUrl.isNotBlank()) epg.value = runCatching { Epg.load(epgUrl) }.getOrDefault(emptyMap())
        channelsLoading.value = false
    }

    fun playChannel(c: Channel) = viewModelScope.launch {
        if (!LinkChecker.isAlive(c.url)) message.value = "Canal no disponible en este momento"
        else playback.value = PlaybackRequest("live:${c.id}", c.name, listOf(Stream(c.url, "En vivo")), live = true)
    }

    fun saveProgress(key: String, pos: Long) = viewModelScope.launch { settings.saveProgress(key, pos) }
    fun toggleFav(id: String) = viewModelScope.launch { settings.toggleFav(id) }
}
