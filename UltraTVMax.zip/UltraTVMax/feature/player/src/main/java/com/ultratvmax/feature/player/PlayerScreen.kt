package com.ultratvmax.feature.player

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.ultratvmax.core.data.PlaybackRequest
import kotlinx.coroutines.delay

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * Reproductor Media3. Calidad adaptativa (HLS/DASH), selector de audio/subtítulos/calidad en el
 * botón de ajustes del propio PlayerView, reanudación y salto automático a la siguiente fuente si una cae.
 */
@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(req: PlaybackRequest, startMs: Long, onSaveProgress: (Long) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var failed by remember { mutableStateOf(false) }
    var idx by remember { mutableIntStateOf(0) }

    val exo = remember {
        ExoPlayer.Builder(ctx)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(15_000, 30_000, 1_500, 3_000).build()) // buffers chicos: poca RAM
            .build().apply { playWhenReady = true }
    }

    fun load(i: Int, pos: Long) {
        val s = req.streams[i]
        val item = MediaItem.Builder().setUri(s.url).setSubtitleConfigurations(
            s.subtitles.map {
                MediaItem.SubtitleConfiguration.Builder(Uri.parse(it.url))
                    .setLanguage(it.lang)
                    .setMimeType(if (it.url.endsWith(".srt")) MimeTypes.APPLICATION_SUBRIP else MimeTypes.TEXT_VTT)
                    .build()
            }
        ).build()
        exo.setMediaItem(item, pos.coerceAtLeast(0))
        exo.prepare()
    }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (idx + 1 < req.streams.size) { idx++; load(idx, exo.currentPosition) } else failed = true
            }
        }
        exo.addListener(listener)
        load(0, startMs)
        onDispose {
            if (!req.live) onSaveProgress(exo.currentPosition)
            exo.removeListener(listener)
            exo.release()
        }
    }

    LaunchedEffect(exo) {
        while (true) {
            delay(10_000)
            if (!req.live && exo.isPlaying) onSaveProgress(exo.currentPosition)
        }
    }

    DisposableEffect(Unit) {
        val act = ctx.findActivity()
        val prev = act?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val controller = act?.window?.let { w ->
            WindowCompat.getInsetsController(w, w.decorView).also {
                it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                it.hide(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            act?.requestedOrientation = prev
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c -> PlayerView(c).apply { player = exo; useController = true; setShowSubtitleButton(true) } },
        )
        TextButton(onClick = onClose, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
            Text("✕ Cerrar", color = Color.White)
        }
        if (failed) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No se pudo reproducir. Se probaron todas las fuentes.", color = Color.White)
                Spacer(Modifier.height(8.dp))
                Button(onClick = onClose) { Text("Volver") }
            }
        }
    }
}
