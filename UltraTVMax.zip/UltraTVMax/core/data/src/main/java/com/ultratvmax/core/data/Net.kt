package com.ultratvmax.core.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

object Http {
    lateinit var client: OkHttpClient
        private set

    fun init(context: Context) {
        if (::client.isInitialized) return
        client = OkHttpClient.Builder()
            .cache(Cache(File(context.cacheDir, "http"), 20L * 1024 * 1024)) // caché acotada: 20 MB
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    suspend fun get(url: String, headers: Map<String, String> = emptyMap()): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).apply { headers.forEach { (k, v) -> addHeader(k, v) } }.build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            r.body!!.string()
        }
    }
}

/** Comprueba que un enlace responde antes de ofrecerlo como "disponible". */
object LinkChecker {
    suspend fun isAlive(url: String): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder().url(url).header("Range", "bytes=0-1023").build()
            Http.client.newBuilder().callTimeout(7, TimeUnit.SECONDS).build()
                .newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }
}
