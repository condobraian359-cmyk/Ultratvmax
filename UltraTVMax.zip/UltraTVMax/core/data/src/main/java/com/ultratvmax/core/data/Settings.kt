package com.ultratvmax.core.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("ultratvmax")

/** Todo se guarda en el dispositivo. La clave de TMDB la pone el usuario: nunca va dentro del APK. */
class SettingsStore(private val ctx: Context) {
    private val kTmdb = stringPreferencesKey("tmdb")
    private val kM3u = stringSetPreferencesKey("m3u")
    private val kEpg = stringPreferencesKey("epg")
    private val kFav = stringSetPreferencesKey("fav")

    val tmdbKey = ctx.ds.data.map { it[kTmdb] ?: "" }
    val m3uUrls = ctx.ds.data.map { it[kM3u] ?: setOf(DEFAULT_M3U) }
    val epgUrl = ctx.ds.data.map { it[kEpg] ?: "" }
    val favorites = ctx.ds.data.map { it[kFav] ?: emptySet() }

    suspend fun setTmdbKey(v: String) { ctx.ds.edit { it[kTmdb] = v.trim() } }
    suspend fun addM3u(u: String) { ctx.ds.edit { it[kM3u] = (it[kM3u] ?: setOf(DEFAULT_M3U)) + u.trim() } }
    suspend fun removeM3u(u: String) { ctx.ds.edit { it[kM3u] = (it[kM3u] ?: setOf(DEFAULT_M3U)) - u } }
    suspend fun setEpg(u: String) { ctx.ds.edit { it[kEpg] = u.trim() } }
    suspend fun toggleFav(id: String) {
        ctx.ds.edit { val s = it[kFav] ?: emptySet(); it[kFav] = if (id in s) s - id else s + id }
    }

    suspend fun progress(key: String): Long = ctx.ds.data.first()[longPreferencesKey("p_$key")] ?: 0L
    suspend fun saveProgress(key: String, pos: Long) { ctx.ds.edit { it[longPreferencesKey("p_$key")] = pos } }

    companion object {
        const val DEFAULT_M3U = "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8"
    }
}
