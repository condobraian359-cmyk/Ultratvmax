package com.ultratvmax.core.data

enum class MediaType { MOVIE, SERIES, ANIME, OTHER }

data class Subtitle(val url: String, val lang: String)

data class Stream(
    val url: String,
    val label: String,
    val audioLang: String? = null,
    val subtitles: List<Subtitle> = emptyList(),
)

/** Playable = hay al menos una fuente verificada. InfoOnly = solo ficha (con plataformas donde se ve, si se conocen). */
sealed interface Availability {
    data class Playable(val streams: List<Stream>) : Availability
    data class InfoOnly(val platforms: List<String> = emptyList()) : Availability
}

data class Title(
    val id: String,
    val sourceId: String,
    val name: String,
    val originalName: String,
    val year: Int?,
    val overview: String?,
    val posterUrl: String?,
    val type: MediaType,
    val genres: List<String>,
    val language: String?,
    val availability: Availability,
)

data class Channel(
    val id: String,
    val name: String,
    val logo: String?,
    val group: String?,
    val country: String?,
    val language: String?,
    val url: String,
    val tvgId: String?,
)

data class Programme(val channelId: String, val title: String, val start: Long, val stop: Long)

data class PlaybackRequest(val key: String, val title: String, val streams: List<Stream>, val live: Boolean)
