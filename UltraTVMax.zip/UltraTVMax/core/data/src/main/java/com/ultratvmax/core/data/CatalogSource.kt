package com.ultratvmax.core.data

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive

internal fun JsonObject.str(k: String): String? = (this[k] as? kotlinx.serialization.json.JsonPrimitive)?.contentOrNull

/** Contrato para añadir fuentes autorizadas: implementa esta interfaz y regístrala en CatalogRepository. */
interface CatalogSource {
    val id: String
    val name: String
    suspend fun browse(section: String = "home", page: Int = 1): List<Title>
    suspend fun search(query: String, page: Int = 1): List<Title>
    suspend fun resolve(title: Title): Availability = title.availability
}
