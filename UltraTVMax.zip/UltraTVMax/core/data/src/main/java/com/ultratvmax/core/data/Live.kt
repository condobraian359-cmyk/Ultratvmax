package com.ultratvmax.core.data

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.zip.GZIPInputStream

object M3u {
    private val attr = Regex("""([\w-]+)="([^"]*)"""")

    /** Lectura en streaming y tope de canales para cuidar la RAM en equipos modestos. */
    suspend fun load(url: String, limit: Int = 3000): List<Channel> = withContext(Dispatchers.IO) {
        val out = ArrayList<Channel>()
        Http.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) return@use
            var info: String? = null
            r.body!!.charStream().buffered().useLines { lines ->
                for (line in lines) {
                    val l = line.trim()
                    if (l.startsWith("#EXTINF")) info = l
                    else if (l.isNotEmpty() && !l.startsWith("#") && info != null) {
                        out += toChannel(info!!, l)
                        info = null
                        if (out.size >= limit) break
                    }
                }
            }
        }
        out
    }

    private fun toChannel(info: String, url: String): Channel {
        val a = attr.findAll(info).associate { it.groupValues[1] to it.groupValues[2] }
        val name = info.substringAfterLast(",").trim().ifBlank { "Canal" }
        return Channel(
            id = a["tvg-id"]?.ifBlank { null } ?: url, name = name, logo = a["tvg-logo"]?.ifBlank { null },
            group = a["group-title"]?.ifBlank { null }, country = a["tvg-country"], language = a["tvg-language"],
            url = url, tvgId = a["tvg-id"]?.ifBlank { null },
        )
    }
}

object Epg {
    /** XMLTV (.xml o .xml.gz). Solo conserva las próximas 12 h para ahorrar memoria. */
    suspend fun load(url: String): Map<String, List<Programme>> = withContext(Dispatchers.IO) {
        Http.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) return@use emptyMap<String, List<Programme>>()
            val raw = r.body!!.byteStream()
            parse(if (url.endsWith(".gz")) GZIPInputStream(raw) else raw)
        }
    }

    private fun parse(ins: InputStream): Map<String, List<Programme>> {
        val p = Xml.newPullParser()
        p.setInput(ins, null)
        val fmt = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
        val now = System.currentTimeMillis()
        val horizon = now + 12 * 3600_000L
        val out = HashMap<String, MutableList<Programme>>()
        var ev = p.eventType
        var ch = ""; var s = 0L; var e = 0L; var title = ""; var inProg = false
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "programme" -> {
                        inProg = true; title = ""
                        ch = p.getAttributeValue(null, "channel") ?: ""
                        s = runCatching { fmt.parse(p.getAttributeValue(null, "start"))!!.time }.getOrDefault(0L)
                        e = runCatching { fmt.parse(p.getAttributeValue(null, "stop"))!!.time }.getOrDefault(0L)
                    }
                    "title" -> if (inProg && title.isEmpty()) title = p.nextText()
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "programme") {
                inProg = false
                if (e > now && s < horizon && title.isNotEmpty()) out.getOrPut(ch) { mutableListOf() }.add(Programme(ch, title, s, e))
            }
            ev = p.next()
        }
        return out
    }
}
