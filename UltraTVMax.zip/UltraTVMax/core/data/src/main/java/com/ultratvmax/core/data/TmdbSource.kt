package com.ultratvmax.core.data

import kotlinx.serialization.json.*
import java.net.URLEncoder

/** TMDB aporta SOLO metadatos (fichas, pósteres, sinopsis, dónde verla). No reproduce nada. */
class TmdbSource(private val apiKey: suspend () -> String, private val lang: String = "es-MX") : CatalogSource {
    override val id = "tmdb"
    override val name = "Tendencias (TMDB)"

    private suspend fun call(path: String, extra: String = ""): JsonObject? {
        val k = apiKey().trim()
        if (k.isEmpty()) return null
        val bearer = k.length > 40 // token v4 (JWT) vs clave v3
        val url = "https://api.themoviedb.org/3$path?language=$lang$extra" + if (bearer) "" else "&api_key=$k"
        val headers = if (bearer) mapOf("Authorization" to "Bearer $k") else emptyMap()
        return Json.parseToJsonElement(Http.get(url, headers)).jsonObject
    }

    override suspend fun browse(section: String, page: Int) = parse(call("/trending/all/week", "&page=$page"))

    override suspend fun search(query: String, page: Int) =
        parse(call("/search/multi", "&include_adult=false&page=$page&query=${URLEncoder.encode(query, "UTF-8")}"))

    // Buscar por actor/director: TMDB devuelve la persona con "known_for"; aplanamos esos títulos.
    private fun parse(root: JsonObject?): List<Title> {
        val results = root?.get("results")?.jsonArray ?: return emptyList()
        val items = results.flatMap { el ->
            val o = el.jsonObject
            if (o.str("media_type") == "person") o["known_for"]?.jsonArray?.map { it.jsonObject } ?: emptyList()
            else listOf(o)
        }
        return items.mapNotNull { toTitle(it) }.distinctBy { it.id }
    }

    private fun toTitle(o: JsonObject): Title? {
        val kind = o.str("media_type") ?: return null
        if (kind != "movie" && kind != "tv") return null
        val name = o.str("title") ?: o.str("name") ?: return null
        val date = o.str("release_date") ?: o.str("first_air_date")
        val genreIds = o["genre_ids"]?.jsonArray?.mapNotNull { it.jsonPrimitive.intOrNull } ?: emptyList()
        val lang = o.str("original_language")
        val type = when {
            16 in genreIds && lang == "ja" -> MediaType.ANIME
            kind == "tv" -> MediaType.SERIES
            else -> MediaType.MOVIE
        }
        return Title(
            id = "tmdb:$kind:${o.str("id")}",
            sourceId = id,
            name = name,
            originalName = o.str("original_title") ?: o.str("original_name") ?: name,
            year = date?.take(4)?.toIntOrNull(),
            overview = o.str("overview")?.ifBlank { null },
            posterUrl = o.str("poster_path")?.let { "https://image.tmdb.org/t/p/w342$it" },
            type = type,
            genres = genreIds.mapNotNull { GENRES[it] },
            language = lang,
            availability = Availability.InfoOnly(),
        )
    }

    override suspend fun resolve(title: Title): Availability {
        val (kind, tid) = title.id.removePrefix("tmdb:").split(":")
        val r = call("/$kind/$tid/watch/providers")?.get("results")?.jsonObject
        val region = listOf("MX", "ES", "US").firstNotNullOfOrNull { r?.get(it)?.jsonObject }
        val names = listOf("free", "ads", "flatrate").flatMap { t ->
            region?.get(t)?.jsonArray?.mapNotNull { it.jsonObject.str("provider_name") } ?: emptyList()
        }.distinct()
        return Availability.InfoOnly(names)
    }

    private companion object {
        val GENRES = mapOf(
            28 to "Acción", 12 to "Aventura", 16 to "Animación", 35 to "Comedia", 80 to "Crimen",
            99 to "Documental", 18 to "Drama", 10751 to "Familia", 14 to "Fantasía", 36 to "Historia",
            27 to "Terror", 10402 to "Música", 9648 to "Misterio", 10749 to "Romance",
            878 to "Ciencia ficción", 53 to "Suspenso", 10752 to "Bélica", 37 to "Western",
            10759 to "Acción y aventura", 10765 to "Sci-Fi y fantasía", 10768 to "Guerra y política",
        )
    }
}
