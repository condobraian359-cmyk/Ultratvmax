package com.ultratvmax.core.data

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

class CatalogRepository(private val sources: List<CatalogSource>, private val archive: ArchiveSource) {

    suspend fun home(): List<Pair<String, List<Title>>> = coroutineScope {
        sources.map { s -> async { s.name to runCatching { s.browse() }.getOrDefault(emptyList()) } }
            .awaitAll().filter { it.second.isNotEmpty() }
    }

    /** Buscador universal: consulta todas las fuentes en paralelo y prioriza lo reproducible. */
    suspend fun search(q: String): List<Title> = coroutineScope {
        sources.map { s -> async { runCatching { s.search(q) }.getOrDefault(emptyList()) } }
            .awaitAll().flatten()
            .distinctBy { it.originalName.lowercase() to it.year }
            .sortedByDescending { it.availability is Availability.Playable }
    }

    /** Antes de abrir una ficha: ¿hay fuente reproducible? ¿en qué plataformas está? */
    suspend fun resolve(t: Title): Title {
        if (t.availability is Availability.Playable) return t
        runCatching { archive.findExact(t.originalName, t.year) }.getOrNull()?.let { return t.copy(availability = it) }
        val src = sources.firstOrNull { it.id == t.sourceId } ?: return t
        return t.copy(availability = runCatching { src.resolve(t) }.getOrDefault(t.availability))
    }
}
