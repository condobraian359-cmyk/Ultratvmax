package com.ultratvmax.core.data

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.*
import java.net.URLEncoder

/** Internet Archive, colección "feature_films" (cine de dominio público). Solo devuelve títulos con enlace verificado. */
class ArchiveSource : CatalogSource {
    override val id = "archive"
    override val name = "Cine de dominio público"

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private suspend fun query(q: String, rows: Int, page: Int): List<Title> {
        val url = "https://archive.org/advancedsearch.php?q=" +
            enc("($q) AND mediatype:movies AND collection:feature_films") +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=year&fl%5B%5D=description" +
            "&sort%5B%5D=downloads+desc&rows=$rows&page=$page&output=json"
        val docs = Json.parseToJsonElement(Http.get(url)).jsonObject["response"]?.jsonObject?.get("docs")?.jsonArray
            ?: return emptyList()
        return coroutineScope {
            docs.map { el ->
                async {
                    val d = el.jsonObject
                    val ident = d.str("identifier") ?: return@async null
                    val streams = runCatching { streamsFor(ident) }.getOrDefault(emptyList())
                    if (streams.isEmpty()) null else {
                        val title = d.str("title") ?: ident
                        Title(
                            id = "archive:$ident", sourceId = id, name = title, originalName = title,
                            year = d.str("year")?.toIntOrNull(), overview = d.str("description")?.take(400),
                            posterUrl = "https://archive.org/services/img/$ident", type = MediaType.MOVIE,
                            genres = emptyList(), language = null, availability = Availability.Playable(streams),
                        )
                    }
                }
            }.awaitAll().filterNotNull()
        }
    }

    override suspend fun browse(section: String, page: Int) = query("*:*", 12, page)

    override suspend fun search(query: String, page: Int) =
        query("title:(${query.replace(Regex("[^\\p{L}\\p{N} ]"), " ")})", 12, page)

    /** Para fichas de TMDB: si existe la misma película en dominio público, pasa a ser reproducible. */
    suspend fun findExact(original: String, year: Int?): Availability.Playable? {
        val hit = query("title:(\"${original.replace("\"", "")}\")", 5, 1).firstOrNull { t ->
            t.name.equals(original, ignoreCase = true) &&
                (year == null || t.year == null || kotlin.math.abs(t.year - year) <= 1)
        } ?: return null
        return hit.availability as? Availability.Playable
    }

    private suspend fun streamsFor(ident: String): List<Stream> {
        val files = Json.parseToJsonElement(Http.get("https://archive.org/metadata/$ident"))
            .jsonObject["files"]?.jsonArray?.map { it.jsonObject } ?: return emptyList()
        val videos = files.filter {
            it.str("format") in setOf("h.264", "MPEG4") && (it.str("size")?.toLongOrNull() ?: 0L) > 30_000_000
        }
        // Primero el archivo más ligero (gama baja), luego el más pesado como respaldo.
        val picks = listOfNotNull(
            videos.minByOrNull { it.str("size")!!.toLong() },
            videos.maxByOrNull { it.str("size")!!.toLong() },
        ).distinctBy { it.str("name") }
        val subs = files.filter { it.str("name")?.let { n -> n.endsWith(".vtt") || n.endsWith(".srt") } == true }
            .take(2).map { Subtitle("https://archive.org/download/$ident/" + enc(it.str("name")!!).replace("+", "%20"), "und") }
        return picks.mapIndexed { i, f ->
            val url = "https://archive.org/download/$ident/" + enc(f.str("name")!!).replace("+", "%20")
            Stream(url, if (i == 0) "Ligera" else "Alta", subtitles = subs)
        }.filter { LinkChecker.isAlive(it.url) }
    }
}
